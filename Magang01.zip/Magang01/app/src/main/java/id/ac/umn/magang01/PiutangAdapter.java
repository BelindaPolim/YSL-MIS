package id.ac.umn.magang01;

public class PiutangAdapter {
}
